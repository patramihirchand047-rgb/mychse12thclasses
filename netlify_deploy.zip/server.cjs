var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express2 = __toESM(require("express"), 1);
var import_path3 = __toESM(require("path"), 1);
var import_vite = require("vite");

// server/apiRoutes.ts
var import_express = require("express");

// server/db.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_crypto2 = __toESM(require("crypto"), 1);
var import_os2 = __toESM(require("os"), 1);

// server/supabase.ts
var import_supabase_js = require("@supabase/supabase-js");
var SUPABASE_PROJECT_ID = process.env.SUPABASE_PROJECT_ID || "ozvjfrpnqcciupluuppc";
var SUPABASE_URL = process.env.SUPABASE_URL || `https://${SUPABASE_PROJECT_ID}.supabase.co`;
var SUPABASE_KEY = process.env.SUPABASE_KEY || process.env.SUPABASE_ANON_KEY || "sb_publishable_oQk1hTI2WzzARMf7sq9KrA_syp3IuAt";
var SUPABASE_SQL_SCHEMA = `-- ==========================================================
-- MY CHSE 12TH CLASSES - SUPABASE DATABASE TABLE SETUP
-- Project ID: ${SUPABASE_PROJECT_ID}
-- Run this in your Supabase SQL Editor:
-- https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql
-- ==========================================================

CREATE TABLE IF NOT EXISTS public.students (
  id TEXT PRIMARY KEY,
  registration_id TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  gmail TEXT UNIQUE NOT NULL,
  age INTEGER NOT NULL,
  stream TEXT NOT NULL,
  subject_1 TEXT NOT NULL,
  subject_2 TEXT NOT NULL,
  subject_3 TEXT NOT NULL,
  subject_4 TEXT NOT NULL,
  subject_5 TEXT NOT NULL,
  subject_6 TEXT NOT NULL,
  state TEXT NOT NULL,
  district TEXT NOT NULL,
  block TEXT NOT NULL,
  address TEXT NOT NULL,
  admission_status TEXT NOT NULL DEFAULT 'Pending',
  registration_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  admission_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

-- Allow public read access to verify student registration status
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'students' AND policyname = 'Allow public read access'
  ) THEN
    CREATE POLICY "Allow public read access" ON public.students
      FOR SELECT
      USING (true);
  END IF;
END $$;

-- Allow public insert for submitting new student registrations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'students' AND policyname = 'Allow public insert'
  ) THEN
    CREATE POLICY "Allow public insert" ON public.students
      FOR INSERT
      WITH CHECK (true);
  END IF;
END $$;

-- Allow public update and delete for management
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'students' AND policyname = 'Allow public update'
  ) THEN
    CREATE POLICY "Allow public update" ON public.students
      FOR UPDATE
      USING (true);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'students' AND policyname = 'Allow public delete'
  ) THEN
    CREATE POLICY "Allow public delete" ON public.students
      FOR DELETE
      USING (true);
  END IF;
END $$;
`;
var PURGED_DEMO_REG_IDS = /* @__PURE__ */ new Set(["MYCHSE-2026-00001", "MYCHSE-2026-00002", "MYCHSE-2026-00003"]);
var PURGED_DEMO_EMAILS = /* @__PURE__ */ new Set(["aarav.mohapatra@gmail.com", "priyanka.das.chse@gmail.com", "rohan.tripathy2026@gmail.com"]);
var clientInstance = null;
function getSupabase() {
  if (!clientInstance) {
    clientInstance = (0, import_supabase_js.createClient)(SUPABASE_URL, SUPABASE_KEY, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
  }
  return clientInstance;
}
async function checkSupabaseStatus() {
  const dashboardSqlUrl = `https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql`;
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.from("students").select("id").limit(1);
    if (error) {
      if (error.code === "PGRST205" || error.message?.includes("schema cache")) {
        return {
          connected: true,
          projectId: SUPABASE_PROJECT_ID,
          supabaseUrl: SUPABASE_URL,
          tableExists: false,
          tableError: "Table 'public.students' does not exist in Supabase schema yet.",
          sqlSchema: SUPABASE_SQL_SCHEMA,
          dashboardSqlUrl
        };
      }
      return {
        connected: false,
        projectId: SUPABASE_PROJECT_ID,
        supabaseUrl: SUPABASE_URL,
        tableExists: false,
        tableError: error.message,
        sqlSchema: SUPABASE_SQL_SCHEMA,
        dashboardSqlUrl
      };
    }
    const countRes = await supabase.from("students").select("*", { count: "exact" });
    return {
      connected: true,
      projectId: SUPABASE_PROJECT_ID,
      supabaseUrl: SUPABASE_URL,
      tableExists: true,
      count: countRes.count ?? (data ? data.length : 0),
      sqlSchema: SUPABASE_SQL_SCHEMA,
      dashboardSqlUrl
    };
  } catch (err) {
    return {
      connected: false,
      projectId: SUPABASE_PROJECT_ID,
      supabaseUrl: SUPABASE_URL,
      tableExists: false,
      tableError: err?.message || "Connection error",
      sqlSchema: SUPABASE_SQL_SCHEMA,
      dashboardSqlUrl
    };
  }
}
async function insertStudentToSupabase(student) {
  try {
    const supabase = getSupabase();
    const { error } = await supabase.from("students").insert({
      id: student.id,
      registration_id: student.registration_id,
      full_name: student.full_name,
      gmail: student.gmail,
      age: student.age,
      stream: student.stream,
      subject_1: student.subject_1,
      subject_2: student.subject_2,
      subject_3: student.subject_3,
      subject_4: student.subject_4,
      subject_5: student.subject_5,
      subject_6: student.subject_6,
      state: student.state,
      district: student.district,
      block: student.block,
      address: student.address,
      admission_status: student.admission_status,
      registration_date: student.registration_date,
      admission_date: student.admission_date,
      created_at: student.created_at,
      updated_at: student.updated_at
    });
    if (error) {
      console.warn("Supabase insert warning:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.warn("Supabase unexpected error during insert:", err);
    return { success: false, error: err?.message || "Unknown error" };
  }
}
async function findStudentInSupabaseByRegistrationId(regId) {
  const normalized = regId.trim().toUpperCase();
  if (PURGED_DEMO_REG_IDS.has(normalized)) {
    return null;
  }
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.from("students").select("*").ilike("registration_id", normalized).limit(1).maybeSingle();
    if (error || !data || PURGED_DEMO_REG_IDS.has(data.registration_id?.toUpperCase())) {
      return null;
    }
    return data;
  } catch {
    return null;
  }
}
async function findStudentInSupabaseByGmail(gmail) {
  const normalized = gmail.trim().toLowerCase();
  if (PURGED_DEMO_EMAILS.has(normalized)) {
    return null;
  }
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.from("students").select("*").ilike("gmail", normalized).limit(1).maybeSingle();
    if (error || !data || PURGED_DEMO_EMAILS.has(data.gmail?.toLowerCase())) {
      return null;
    }
    return data;
  } catch {
    return null;
  }
}
async function updateStudentInSupabase(student) {
  try {
    const supabase = getSupabase();
    const { error } = await supabase.from("students").update({
      full_name: student.full_name,
      gmail: student.gmail,
      age: student.age,
      stream: student.stream,
      subject_1: student.subject_1,
      subject_2: student.subject_2,
      subject_3: student.subject_3,
      subject_4: student.subject_4,
      subject_5: student.subject_5,
      subject_6: student.subject_6,
      state: student.state,
      district: student.district,
      block: student.block,
      address: student.address,
      admission_status: student.admission_status,
      admission_date: student.admission_date,
      updated_at: student.updated_at
    }).eq("registration_id", student.registration_id);
    if (error) {
      console.warn("Supabase update warning:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.warn("Supabase unexpected error during update:", err);
    return { success: false, error: err?.message || "Unknown error" };
  }
}
async function deleteStudentInSupabase(registrationId) {
  try {
    const supabase = getSupabase();
    const { error } = await supabase.from("students").delete().eq("registration_id", registrationId);
    if (error) {
      console.warn("Supabase delete warning:", error.message);
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err) {
    console.warn("Supabase unexpected error during delete:", err);
    return { success: false, error: err?.message || "Unknown error" };
  }
}
async function fetchAllStudentsFromSupabase() {
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.from("students").select("*").order("created_at", { ascending: true });
    if (error || !data) {
      return [];
    }
    return data.filter(
      (s) => !PURGED_DEMO_REG_IDS.has(s.registration_id?.toUpperCase()) && !PURGED_DEMO_EMAILS.has(s.gmail?.toLowerCase())
    );
  } catch {
    return [];
  }
}
async function getMaxRegistrationNumberFromSupabase() {
  try {
    const supabase = getSupabase();
    const { data, error } = await supabase.from("students").select("registration_id").order("registration_id", { ascending: false }).limit(100);
    if (error || !data) return 0;
    const prefix = "MYCHSE-2026-";
    let max = 0;
    for (const row of data) {
      if (row.registration_id && row.registration_id.startsWith(prefix)) {
        const num = parseInt(row.registration_id.substring(prefix.length), 10);
        if (!isNaN(num) && num > max) {
          max = num;
        }
      }
    }
    return max;
  } catch {
    return 0;
  }
}

// server/adminAuth.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_os = __toESM(require("os"), 1);
function getDataDir() {
  if (process.env.DATA_DIR) return process.env.DATA_DIR;
  if (process.env.NETLIFY || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.VERCEL) {
    return import_path.default.join(import_os.default.tmpdir(), "mychse_data");
  }
  const defaultDir = import_path.default.join(process.cwd(), "data");
  try {
    if (!import_fs.default.existsSync(defaultDir)) {
      import_fs.default.mkdirSync(defaultDir, { recursive: true });
    }
    return defaultDir;
  } catch {
    return import_path.default.join(import_os.default.tmpdir(), "mychse_data");
  }
}
function getAdminFilePath() {
  return import_path.default.join(getDataDir(), "admin.json");
}
function getAuditFilePath() {
  return import_path.default.join(getDataDir(), "audit_logs.json");
}
var activeSessions = /* @__PURE__ */ new Map();
var SESSION_SECRET = process.env.SESSION_SECRET || "mychse-office-2026-secure-secret-key";
function createSignedSessionToken(session) {
  const payload = Buffer.from(JSON.stringify(session)).toString("base64url");
  const signature = import_crypto.default.createHmac("sha256", SESSION_SECRET).update(payload).digest("base64url");
  return `adm_sess_${payload}.${signature}`;
}
function verifySignedSessionToken(token) {
  if (!token || !token.startsWith("adm_sess_")) return null;
  const content = token.slice("adm_sess_".length);
  const dotIndex = content.lastIndexOf(".");
  if (dotIndex === -1) return null;
  const payload = content.slice(0, dotIndex);
  const signature = content.slice(dotIndex + 1);
  const expectedSignature = import_crypto.default.createHmac("sha256", SESSION_SECRET).update(payload).digest("base64url");
  if (signature !== expectedSignature) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf-8"));
    if (Date.now() > data.expires_at) return null;
    return {
      token,
      admin_id: data.admin_id,
      email: data.email,
      name: data.name,
      role: data.role,
      expires_at: data.expires_at
    };
  } catch {
    return null;
  }
}
function hashPassword(password, salt) {
  return import_crypto.default.pbkdf2Sync(password, salt, 1e4, 64, "sha512").toString("hex");
}
function ensureDataDirectory() {
  try {
    const dir = getDataDir();
    if (!import_fs.default.existsSync(dir)) {
      import_fs.default.mkdirSync(dir, { recursive: true });
    }
  } catch (err) {
    console.warn("Storage directory note:", err);
  }
}
var inMemoryAdminUsers = null;
function getAdminUsers() {
  ensureDataDirectory();
  let users = inMemoryAdminUsers ? [...inMemoryAdminUsers] : [];
  const adminFile = getAdminFilePath();
  if (users.length === 0 && import_fs.default.existsSync(adminFile)) {
    try {
      const content = import_fs.default.readFileSync(adminFile, "utf-8");
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed)) {
        users = parsed;
      } else if (parsed && typeof parsed === "object" && parsed.email) {
        users = [parsed];
      }
    } catch (err) {
      console.warn("Failed to parse admin.json, re-initializing admin accounts:", err);
    }
  }
  let modified = false;
  const targetEmail = "patramihirchand66@gmail.com".toLowerCase();
  const officeAdminIndex = users.findIndex((u) => u.email.toLowerCase() === targetEmail);
  if (officeAdminIndex === -1) {
    const salt = import_crypto.default.randomBytes(16).toString("hex");
    const password_hash = hashPassword("Ms@2026", salt);
    const officeAdmin = {
      id: "admin_patramihirchand66",
      email: targetEmail,
      name: "Mihirchand Patra",
      role: "Office Administrator",
      salt,
      password_hash,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_login: null
    };
    users.unshift(officeAdmin);
    modified = true;
  } else {
    const admin = users[officeAdminIndex];
    const testHash = hashPassword("Ms@2026", admin.salt);
    if (testHash !== admin.password_hash) {
      const salt = import_crypto.default.randomBytes(16).toString("hex");
      admin.salt = salt;
      admin.password_hash = hashPassword("Ms@2026", salt);
      admin.name = admin.name || "Mihirchand Patra";
      admin.role = admin.role || "Office Administrator";
      modified = true;
    }
  }
  const defaultEmail = (process.env.ADMIN_EMAIL || "admin@mychse12thclasses.edu.in").toLowerCase().trim();
  if (!users.some((u) => u.email.toLowerCase() === defaultEmail)) {
    const defaultPassword = process.env.ADMIN_PASSWORD || "Admin@CHSE2026!";
    const salt = import_crypto.default.randomBytes(16).toString("hex");
    const password_hash = hashPassword(defaultPassword, salt);
    users.push({
      id: "admin_" + import_crypto.default.randomUUID(),
      email: defaultEmail,
      name: "Super Administrator",
      role: "Super Administrator",
      salt,
      password_hash,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      last_login: null
    });
    modified = true;
  }
  if (modified) {
    saveAdminUsers(users);
  }
  return users;
}
function saveAdminUsers(users) {
  inMemoryAdminUsers = [...users];
  try {
    ensureDataDirectory();
    const adminFile = getAdminFilePath();
    const tempFile = `${adminFile}.tmp.${Date.now()}`;
    import_fs.default.writeFileSync(tempFile, JSON.stringify(users, null, 2), "utf-8");
    import_fs.default.renameSync(tempFile, adminFile);
  } catch (err) {
    console.warn("Admin user storage note (in-memory active):", err);
  }
}
function saveAdminUser(admin) {
  const users = getAdminUsers();
  const idx = users.findIndex((u) => u.id === admin.id || u.email.toLowerCase() === admin.email.toLowerCase());
  if (idx !== -1) {
    users[idx] = admin;
  } else {
    users.push(admin);
  }
  saveAdminUsers(users);
}
function authenticateAdmin(email, password) {
  const users = getAdminUsers();
  const normalizedEmail = email.trim().toLowerCase();
  const admin = users.find((u) => u.email.toLowerCase() === normalizedEmail);
  if (!admin) {
    throw new Error("Invalid email or password.");
  }
  const computedHash = hashPassword(password, admin.salt);
  if (!import_crypto.default.timingSafeEqual(Buffer.from(computedHash, "hex"), Buffer.from(admin.password_hash, "hex"))) {
    throw new Error("Invalid email or password.");
  }
  admin.last_login = (/* @__PURE__ */ new Date()).toISOString();
  saveAdminUser(admin);
  const expires_at = Date.now() + 24 * 60 * 60 * 1e3;
  const tokenPayload = {
    admin_id: admin.id,
    email: admin.email,
    name: admin.name,
    role: admin.role,
    expires_at
  };
  const token = createSignedSessionToken(tokenPayload);
  const session = {
    token,
    ...tokenPayload
  };
  activeSessions.set(token, session);
  addAuditLog(admin.email, "ADMIN_LOGIN", `Office user logged into Admin Portal: ${admin.name} (${admin.email})`);
  return {
    session,
    admin: {
      id: admin.id,
      email: admin.email,
      name: admin.name,
      role: admin.role,
      created_at: admin.created_at,
      last_login: admin.last_login
    }
  };
}
function verifyAdminToken(token) {
  if (!token) return null;
  const session = activeSessions.get(token);
  if (session) {
    if (Date.now() > session.expires_at) {
      activeSessions.delete(token);
      return null;
    }
    return session;
  }
  const verified = verifySignedSessionToken(token);
  if (verified) {
    activeSessions.set(token, verified);
    return verified;
  }
  return null;
}
function logoutAdmin(token) {
  if (!token) return false;
  const session = activeSessions.get(token);
  if (session) {
    addAuditLog(session.email, "ADMIN_LOGOUT", "Administrator logged out of Admin Panel");
  }
  return activeSessions.delete(token);
}
function changeAdminPassword(currentPassword, newPassword, adminEmail) {
  const users = getAdminUsers();
  const admin = adminEmail ? users.find((u) => u.email.toLowerCase() === adminEmail.trim().toLowerCase()) : users[0];
  if (!admin) {
    throw new Error("Admin user not found.");
  }
  const computedHash = hashPassword(currentPassword, admin.salt);
  if (!import_crypto.default.timingSafeEqual(Buffer.from(computedHash, "hex"), Buffer.from(admin.password_hash, "hex"))) {
    throw new Error("Current password is incorrect.");
  }
  if (!newPassword || newPassword.length < 6) {
    throw new Error("New password must be at least 6 characters long.");
  }
  const newSalt = import_crypto.default.randomBytes(16).toString("hex");
  const newHash = hashPassword(newPassword, newSalt);
  admin.salt = newSalt;
  admin.password_hash = newHash;
  saveAdminUser(admin);
  addAuditLog(admin.email, "PASSWORD_CHANGE", `Password changed successfully for ${admin.email}`);
}
function getAuditLogs(limit = 100) {
  try {
    ensureDataDirectory();
    const auditFile = getAuditFilePath();
    if (!import_fs.default.existsSync(auditFile)) {
      return [];
    }
    const raw = import_fs.default.readFileSync(auditFile, "utf-8");
    const logs = JSON.parse(raw);
    return logs.slice(0, limit);
  } catch {
    return [];
  }
}
function addAuditLog(adminEmail, action, details, registrationId) {
  try {
    ensureDataDirectory();
    const auditFile = getAuditFilePath();
    let logs = [];
    if (import_fs.default.existsSync(auditFile)) {
      try {
        logs = JSON.parse(import_fs.default.readFileSync(auditFile, "utf-8"));
      } catch {
        logs = [];
      }
    }
    const entry = {
      id: "log_" + import_crypto.default.randomUUID(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      admin_email: adminEmail,
      action,
      registration_id: registrationId,
      details
    };
    logs.unshift(entry);
    if (logs.length > 500) {
      logs = logs.slice(0, 500);
    }
    import_fs.default.writeFileSync(auditFile, JSON.stringify(logs, null, 2), "utf-8");
  } catch (err) {
    console.warn("Failed to save audit log entry (handled in serverless):", err);
  }
}

// server/db.ts
function getDataDir2() {
  if (process.env.DATA_DIR) {
    return process.env.DATA_DIR;
  }
  if (process.env.NETLIFY || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.VERCEL) {
    return import_path2.default.join(import_os2.default.tmpdir(), "mychse_data");
  }
  const defaultDir = import_path2.default.join(process.cwd(), "data");
  try {
    if (!import_fs2.default.existsSync(defaultDir)) {
      import_fs2.default.mkdirSync(defaultDir, { recursive: true });
    }
    return defaultDir;
  } catch {
    return import_path2.default.join(import_os2.default.tmpdir(), "mychse_data");
  }
}
var INITIAL_STUDENTS = [];
function initDb() {
  try {
    const dir = getDataDir2();
    if (!import_fs2.default.existsSync(dir)) {
      import_fs2.default.mkdirSync(dir, { recursive: true });
    }
    const dbFile = import_path2.default.join(dir, "students.json");
    if (!import_fs2.default.existsSync(dbFile)) {
      import_fs2.default.writeFileSync(dbFile, JSON.stringify(INITIAL_STUDENTS, null, 2), "utf-8");
    }
  } catch (err) {
    console.warn("Storage init note (serverless fallback active):", err);
  }
}
function getAllStudents() {
  initDb();
  try {
    const dbFile = import_path2.default.join(getDataDir2(), "students.json");
    if (!import_fs2.default.existsSync(dbFile)) return [];
    const data = import_fs2.default.readFileSync(dbFile, "utf-8");
    const parsed = JSON.parse(data);
    return parsed.filter((s) => !s.id?.startsWith("std_seed_"));
  } catch (err) {
    console.error("Error reading students database:", err);
    return [];
  }
}
function saveStudents(students) {
  try {
    initDb();
    const dbFile = import_path2.default.join(getDataDir2(), "students.json");
    const tempFile = `${dbFile}.${Date.now()}.tmp`;
    import_fs2.default.writeFileSync(tempFile, JSON.stringify(students, null, 2), "utf-8");
    import_fs2.default.renameSync(tempFile, dbFile);
  } catch (err) {
    console.warn("Local file write notice (data safely handled/synced):", err);
  }
}
function findStudentByGmail(gmail) {
  const normalized = gmail.trim().toLowerCase();
  const students = getAllStudents();
  return students.find((s) => s.gmail.trim().toLowerCase() === normalized);
}
function findStudentByRegistrationId(regId) {
  const normalized = regId.trim().toUpperCase();
  const students = getAllStudents();
  return students.find((s) => s.registration_id.trim().toUpperCase() === normalized);
}
function generateNextRegistrationId(existingStudents, minNumber = 0) {
  let highestNum = minNumber;
  const prefix = "MYCHSE-2026-";
  for (const s of existingStudents) {
    if (s.registration_id && s.registration_id.startsWith(prefix)) {
      const numPart = s.registration_id.substring(prefix.length);
      const parsed = parseInt(numPart, 10);
      if (!isNaN(parsed) && parsed > highestNum) {
        highestNum = parsed;
      }
    }
  }
  const nextNum = highestNum + 1;
  const padded = String(nextNum).padStart(5, "0");
  return `${prefix}${padded}`;
}
async function createStudentWithSupabase(data) {
  const students = getAllStudents();
  const existingWithGmail = findStudentByGmail(data.gmail);
  if (existingWithGmail) {
    const error = new Error("This Gmail ID is already registered.");
    error.code = "DUPLICATE_GMAIL";
    error.existingRegistrationId = existingWithGmail.registration_id;
    throw error;
  }
  const supabaseExisting = await findStudentInSupabaseByGmail(data.gmail);
  if (supabaseExisting) {
    const error = new Error("This Gmail ID is already registered in Supabase database.");
    error.code = "DUPLICATE_GMAIL";
    error.existingRegistrationId = supabaseExisting.registration_id;
    throw error;
  }
  const sbMaxNum = await getMaxRegistrationNumberFromSupabase();
  const registration_id = generateNextRegistrationId(students, sbMaxNum);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const newStudent = {
    id: "std_" + import_crypto2.default.randomUUID(),
    registration_id,
    full_name: data.full_name.trim(),
    gmail: data.gmail.trim().toLowerCase(),
    age: Number(data.age),
    stream: data.stream,
    subject_1: data.subject_1.trim(),
    subject_2: data.subject_2.trim(),
    subject_3: data.subject_3.trim(),
    subject_4: data.subject_4.trim(),
    subject_5: data.subject_5.trim(),
    subject_6: data.subject_6.trim(),
    state: data.state.trim(),
    district: data.district.trim(),
    block: data.block.trim(),
    address: data.address.trim(),
    admission_status: "Pending",
    registration_date: now,
    admission_date: null,
    created_at: now,
    updated_at: now,
    synced_to_supabase: false
  };
  const sbResult = await insertStudentToSupabase(newStudent);
  if (sbResult.success) {
    newStudent.synced_to_supabase = true;
  }
  students.push(newStudent);
  saveStudents(students);
  return {
    student: newStudent,
    supabaseSynced: sbResult.success,
    supabaseError: sbResult.error
  };
}
async function findStudentByRegistrationIdAsync(regId) {
  const localStudent = findStudentByRegistrationId(regId);
  if (localStudent) {
    return localStudent;
  }
  const supabaseStudent = await findStudentInSupabaseByRegistrationId(regId);
  if (supabaseStudent) {
    const students = getAllStudents();
    if (!students.some((s) => s.registration_id === supabaseStudent.registration_id)) {
      students.push({ ...supabaseStudent, synced_to_supabase: true });
      saveStudents(students);
    }
    return supabaseStudent;
  }
  return void 0;
}
async function syncAllStudentsToSupabase() {
  const students = getAllStudents();
  let synced = 0;
  let failed = 0;
  const errors = [];
  for (const student of students) {
    const res = await insertStudentToSupabase(student);
    if (res.success) {
      student.synced_to_supabase = true;
      synced++;
    } else {
      failed++;
      if (res.error && !errors.includes(res.error)) {
        errors.push(res.error);
      }
    }
  }
  saveStudents(students);
  return { total: students.length, synced, failed, errors };
}
async function syncFromSupabaseToLocal() {
  try {
    const supabaseStudents = await fetchAllStudentsFromSupabase();
    if (!supabaseStudents || supabaseStudents.length === 0) {
      return 0;
    }
    const localStudents = getAllStudents();
    const localMap = new Map(localStudents.map((s) => [s.registration_id.toUpperCase(), s]));
    let addedOrUpdated = 0;
    for (const sb of supabaseStudents) {
      const existing = localMap.get(sb.registration_id.toUpperCase());
      if (!existing) {
        localStudents.push({ ...sb, synced_to_supabase: true });
        addedOrUpdated++;
      }
    }
    if (addedOrUpdated > 0) {
      saveStudents(localStudents);
    }
    return addedOrUpdated;
  } catch (err) {
    console.warn("Error syncing from Supabase to local:", err);
    return 0;
  }
}
async function updateStudentAdmissionStatus(registrationId, newStatus, adminEmail) {
  const students = getAllStudents();
  const normalized = registrationId.trim().toUpperCase();
  const index = students.findIndex((s) => s.registration_id.trim().toUpperCase() === normalized);
  if (index === -1) {
    throw new Error(`Student with Registration ID ${registrationId} not found.`);
  }
  const student = students[index];
  const oldStatus = student.admission_status;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  student.admission_status = newStatus;
  student.updated_at = now;
  if (newStatus === "Approval" || newStatus === "Admitted") {
    student.admission_date = now;
  } else {
    student.admission_date = null;
  }
  saveStudents(students);
  await updateStudentInSupabase(student);
  addAuditLog(
    adminEmail,
    newStatus === "Approval" || newStatus === "Admitted" ? "APPROVE_STUDENT" : newStatus === "Rejected" ? "REJECT_STUDENT" : "CHANGE_STATUS",
    `Changed status for ${student.full_name} (${student.registration_id}) from ${oldStatus} to ${newStatus}`,
    student.registration_id
  );
  return student;
}
async function updateStudentDetails(registrationId, data, adminEmail) {
  const students = getAllStudents();
  const normalized = registrationId.trim().toUpperCase();
  const index = students.findIndex((s) => s.registration_id.trim().toUpperCase() === normalized);
  if (index === -1) {
    throw new Error(`Student with Registration ID ${registrationId} not found.`);
  }
  const student = students[index];
  if (data.gmail && data.gmail.trim().toLowerCase() !== student.gmail.toLowerCase()) {
    const existing = students.find(
      (s) => s.gmail.toLowerCase() === data.gmail.trim().toLowerCase() && s.registration_id !== student.registration_id
    );
    if (existing) {
      throw new Error(`Gmail ${data.gmail} is already registered by another student (${existing.registration_id}).`);
    }
    student.gmail = data.gmail.trim().toLowerCase();
  }
  if (data.full_name) student.full_name = data.full_name.trim();
  if (data.age) student.age = Number(data.age);
  if (data.stream) student.stream = data.stream;
  if (data.subject_1) student.subject_1 = data.subject_1.trim();
  if (data.subject_2) student.subject_2 = data.subject_2.trim();
  if (data.subject_3) student.subject_3 = data.subject_3.trim();
  if (data.subject_4) student.subject_4 = data.subject_4.trim();
  if (data.subject_5) student.subject_5 = data.subject_5.trim();
  if (data.subject_6) student.subject_6 = data.subject_6.trim();
  if (data.state) student.state = data.state.trim();
  if (data.district) student.district = data.district.trim();
  if (data.block) student.block = data.block.trim();
  if (data.address) student.address = data.address.trim();
  student.updated_at = (/* @__PURE__ */ new Date()).toISOString();
  saveStudents(students);
  await updateStudentInSupabase(student);
  addAuditLog(
    adminEmail,
    "EDIT_STUDENT",
    `Updated details for ${student.full_name} (${student.registration_id})`,
    student.registration_id
  );
  return student;
}
async function deleteStudent(registrationId, adminEmail) {
  const students = getAllStudents();
  const normalized = registrationId.trim().toUpperCase();
  const index = students.findIndex((s) => s.registration_id.trim().toUpperCase() === normalized);
  if (index === -1) {
    throw new Error(`Student with Registration ID ${registrationId} not found.`);
  }
  const [removed] = students.splice(index, 1);
  saveStudents(students);
  await deleteStudentInSupabase(removed.registration_id);
  addAuditLog(
    adminEmail,
    "DELETE_STUDENT",
    `Permanently deleted student ${removed.full_name} (${removed.registration_id})`,
    removed.registration_id
  );
  return true;
}
async function bulkUpdateAdmissionStatus(registrationIds, newStatus, adminEmail) {
  const students = getAllStudents();
  const normalizedIds = new Set(registrationIds.map((id) => id.trim().toUpperCase()));
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const updatedIds = [];
  for (const student of students) {
    if (normalizedIds.has(student.registration_id.trim().toUpperCase())) {
      student.admission_status = newStatus;
      student.updated_at = now;
      if (newStatus === "Approval" || newStatus === "Admitted") {
        student.admission_date = now;
      } else {
        student.admission_date = null;
      }
      updatedIds.push(student.registration_id);
      updateStudentInSupabase(student).catch((e) => console.warn("Supabase bulk update error:", e));
    }
  }
  saveStudents(students);
  addAuditLog(
    adminEmail,
    "BULK_STATUS_CHANGE",
    `Bulk updated ${updatedIds.length} students to ${newStatus}`
  );
  return { updatedCount: updatedIds.length, updatedIds };
}
async function bulkDeleteStudents(registrationIds, adminEmail) {
  let students = getAllStudents();
  const normalizedIds = new Set(registrationIds.map((id) => id.trim().toUpperCase()));
  const toDelete = students.filter((s) => normalizedIds.has(s.registration_id.trim().toUpperCase()));
  const deletedIds = toDelete.map((s) => s.registration_id);
  students = students.filter((s) => !normalizedIds.has(s.registration_id.trim().toUpperCase()));
  saveStudents(students);
  for (const id of deletedIds) {
    deleteStudentInSupabase(id).catch((e) => console.warn("Supabase bulk delete error:", e));
  }
  addAuditLog(
    adminEmail,
    "BULK_DELETE",
    `Bulk deleted ${deletedIds.length} students`
  );
  return { deletedCount: deletedIds.length, deletedIds };
}
function getAdminStatistics() {
  const students = getAllStudents();
  let pending = 0;
  let approval = 0;
  let rejected = 0;
  let arts = 0;
  let science = 0;
  let commerce = 0;
  for (const s of students) {
    if (s.admission_status === "Pending") pending++;
    else if (s.admission_status === "Approval" || s.admission_status === "Admitted") approval++;
    else if (s.admission_status === "Rejected") rejected++;
    if (s.stream === "Arts") arts++;
    else if (s.stream === "Science") science++;
    else if (s.stream === "Commerce") commerce++;
  }
  const recent = [...students].sort((a, b) => new Date(b.registration_date).getTime() - new Date(a.registration_date).getTime()).slice(0, 10);
  return {
    total: students.length,
    pending,
    approval,
    admitted: approval,
    rejected,
    streams: {
      arts,
      science,
      commerce
    },
    recentRegistrations: recent
  };
}
function getAdminStudentsList(options = {}) {
  let list = getAllStudents();
  const availableStates = Array.from(new Set(list.map((s) => s.state).filter(Boolean))).sort();
  const availableDistricts = Array.from(
    new Set(
      list.filter((s) => !options.state || s.state.toLowerCase() === options.state.toLowerCase()).map((s) => s.district).filter(Boolean)
    )
  ).sort();
  const availableBlocks = Array.from(
    new Set(
      list.filter((s) => {
        if (options.state && s.state.toLowerCase() !== options.state.toLowerCase()) return false;
        if (options.district && s.district.toLowerCase() !== options.district.toLowerCase()) return false;
        return true;
      }).map((s) => s.block).filter(Boolean)
    )
  ).sort();
  if (options.search && options.search.trim() !== "") {
    const q = options.search.trim().toLowerCase();
    list = list.filter(
      (s) => s.full_name.toLowerCase().includes(q) || s.gmail.toLowerCase().includes(q) || s.registration_id.toLowerCase().includes(q)
    );
  }
  if (options.stream && options.stream !== "All") {
    list = list.filter((s) => s.stream.toLowerCase() === options.stream.toLowerCase());
  }
  if (options.status && options.status !== "All") {
    const filterStatus = options.status.toLowerCase();
    if (filterStatus === "approval" || filterStatus === "admitted") {
      list = list.filter(
        (s) => s.admission_status.toLowerCase() === "approval" || s.admission_status.toLowerCase() === "admitted"
      );
    } else {
      list = list.filter((s) => s.admission_status.toLowerCase() === filterStatus);
    }
  }
  if (options.state && options.state !== "All") {
    list = list.filter((s) => s.state.toLowerCase() === options.state.toLowerCase());
  }
  if (options.district && options.district !== "All") {
    list = list.filter((s) => s.district.toLowerCase() === options.district.toLowerCase());
  }
  if (options.block && options.block !== "All") {
    list = list.filter((s) => s.block.toLowerCase() === options.block.toLowerCase());
  }
  const sortBy = options.sortBy || "registration_date";
  const sortOrder = options.sortOrder === "asc" ? 1 : -1;
  list.sort((a, b) => {
    let valA = a[sortBy] ?? "";
    let valB = b[sortBy] ?? "";
    if (sortBy === "registration_date" || sortBy === "admission_date") {
      const timeA = valA ? new Date(valA).getTime() : 0;
      const timeB = valB ? new Date(valB).getTime() : 0;
      return (timeA - timeB) * sortOrder;
    }
    if (typeof valA === "string") {
      return valA.localeCompare(String(valB)) * sortOrder;
    }
    return (valA - valB) * sortOrder;
  });
  const totalCount = list.length;
  const page = Math.max(1, Number(options.page) || 1);
  const limit = Math.max(1, Number(options.limit) || 25);
  const totalPages = Math.max(1, Math.ceil(totalCount / limit));
  const startIndex = (page - 1) * limit;
  const paginatedStudents = list.slice(startIndex, startIndex + limit);
  return {
    students: paginatedStudents,
    totalCount,
    page,
    totalPages,
    limit,
    availableStates,
    availableDistricts,
    availableBlocks
  };
}

// server/apiRoutes.ts
function requireAdminAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  const customHeader = req.headers["x-admin-token"];
  let token;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.substring(7).trim();
  } else if (customHeader) {
    token = customHeader.trim();
  }
  const session = verifyAdminToken(token);
  if (!session) {
    return res.status(401).json({
      error: "Unauthorized",
      message: "Access denied. Valid administrator credentials required."
    });
  }
  req.adminSession = session;
  next();
}
var apiRouter = (0, import_express.Router)();
apiRouter.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "MY CHSE 12TH CLASSES API",
    database: "Supabase Cloud (PostgreSQL) + Persistent Cache",
    supabase_project_id: SUPABASE_PROJECT_ID,
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
apiRouter.get("/supabase/status", async (req, res) => {
  try {
    const status = await checkSupabaseStatus();
    res.json(status);
  } catch (err) {
    res.status(500).json({
      connected: false,
      error: err?.message || "Error checking Supabase status",
      projectId: SUPABASE_PROJECT_ID,
      supabaseUrl: SUPABASE_URL,
      sqlSchema: SUPABASE_SQL_SCHEMA
    });
  }
});
apiRouter.post("/supabase/sync", async (req, res) => {
  try {
    const result = await syncAllStudentsToSupabase();
    res.json({
      success: true,
      message: `Processed ${result.total} records: ${result.synced} synced, ${result.failed} failed/pending schema.`,
      ...result
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err?.message || "Failed to sync with Supabase"
    });
  }
});
apiRouter.post("/students/register", async (req, res) => {
  try {
    const {
      full_name,
      gmail,
      age,
      stream,
      subject_1,
      subject_2,
      subject_3,
      subject_4,
      subject_5,
      subject_6,
      state,
      district,
      block,
      address,
      confirmed
    } = req.body;
    const errors = {};
    if (!full_name || typeof full_name !== "string" || full_name.trim().length < 3) {
      errors.full_name = "Please enter your complete full name (at least 3 characters).";
    }
    if (!gmail || typeof gmail !== "string") {
      errors.gmail = "Please enter your Gmail ID.";
    } else {
      const trimmedGmail = gmail.trim().toLowerCase();
      const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/i;
      if (!emailRegex.test(trimmedGmail)) {
        errors.gmail = "Please enter a valid Gmail ID ending with @gmail.com.";
      }
    }
    const numAge = Number(age);
    if (!age || isNaN(numAge) || numAge < 14 || numAge > 35) {
      errors.age = "Please enter a valid student age between 14 and 35.";
    }
    const validStreams = ["Arts", "Science", "Commerce"];
    if (!stream || !validStreams.includes(stream)) {
      errors.stream = "Please select a valid stream (Arts, Science, or Commerce).";
    }
    const subjects = [subject_1, subject_2, subject_3, subject_4, subject_5, subject_6];
    for (let i = 0; i < 6; i++) {
      if (!subjects[i] || typeof subjects[i] !== "string" || subjects[i].trim() === "") {
        errors[`subject_${i + 1}`] = `Please select Subject ${i + 1}.`;
      }
    }
    const validSelectedSubjects = subjects.filter((s) => s && typeof s === "string" && s.trim() !== "");
    const uniqueSubjects = new Set(validSelectedSubjects.map((s) => s.trim().toLowerCase()));
    if (validSelectedSubjects.length === 6 && uniqueSubjects.size < 6) {
      errors.subjects = "All six subjects must be distinct. Duplicate subject selection is not allowed.";
    }
    if (!state || typeof state !== "string" || state.trim() === "") {
      errors.state = "Please select your State.";
    }
    if (!district || typeof district !== "string" || district.trim() === "") {
      errors.district = "Please select your District.";
    }
    if (!block || typeof block !== "string" || block.trim() === "") {
      errors.block = "Please select your Block.";
    }
    if (!address || typeof address !== "string" || address.trim().length < 8) {
      errors.address = "Please enter your complete residential address (at least 8 characters).";
    }
    if (confirmed !== true) {
      errors.confirmed = "You must confirm that the provided information is correct.";
    }
    if (Object.keys(errors).length > 0) {
      return res.status(400).json({
        error: "Validation failed",
        errors
      });
    }
    const { student: newStudent, supabaseSynced, supabaseError } = await createStudentWithSupabase({
      full_name,
      gmail,
      age: numAge,
      stream,
      subject_1,
      subject_2,
      subject_3,
      subject_4,
      subject_5,
      subject_6,
      state,
      district,
      block,
      address
    });
    return res.status(201).json({
      success: true,
      supabase_synced: supabaseSynced,
      supabase_error: supabaseError,
      supabase_project_id: SUPABASE_PROJECT_ID,
      student: {
        registration_id: newStudent.registration_id,
        full_name: newStudent.full_name,
        stream: newStudent.stream,
        registration_date: newStudent.registration_date,
        admission_status: newStudent.admission_status
      }
    });
  } catch (err) {
    if (err.code === "DUPLICATE_GMAIL") {
      return res.status(409).json({
        error: "This Gmail ID is already registered.",
        code: "DUPLICATE_GMAIL",
        existingRegistrationId: err.existingRegistrationId
      });
    }
    console.error("Server registration error:", err);
    return res.status(500).json({
      error: "An unexpected server error occurred while processing registration."
    });
  }
});
apiRouter.get("/students/status/:registrationId", async (req, res) => {
  const { registrationId } = req.params;
  if (!registrationId || typeof registrationId !== "string" || registrationId.trim() === "") {
    return res.status(400).json({
      error: "Invalid request",
      message: "Registration ID is required."
    });
  }
  const student = await findStudentByRegistrationIdAsync(registrationId);
  if (!student) {
    return res.status(404).json({
      error: "Registration ID not found.",
      message: "Please check your Registration ID and try again."
    });
  }
  return res.json({
    registration_id: student.registration_id,
    full_name: student.full_name,
    stream: student.stream,
    registration_date: student.registration_date,
    admission_status: student.admission_status,
    admission_date: student.admission_date,
    synced_to_supabase: student.synced_to_supabase
  });
});
apiRouter.get("/students/check-gmail", async (req, res) => {
  const gmail = req.query.gmail;
  if (!gmail) {
    return res.status(400).json({ error: "gmail is required" });
  }
  const student = findStudentByGmail(gmail);
  if (student) {
    return res.json({
      isRegistered: true,
      registration_id: student.registration_id
    });
  }
  const supabaseStudent = await findStudentInSupabaseByGmail(gmail);
  if (supabaseStudent) {
    return res.json({
      isRegistered: true,
      registration_id: supabaseStudent.registration_id
    });
  }
  return res.json({ isRegistered: false });
});
apiRouter.post("/admin/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required." });
    }
    const auth = authenticateAdmin(email, password);
    return res.json({
      success: true,
      token: auth.session.token,
      admin: auth.admin
    });
  } catch (err) {
    return res.status(401).json({
      error: err?.message || "Invalid email or password."
    });
  }
});
apiRouter.get("/admin/me", requireAdminAuth, (req, res) => {
  const session = req.adminSession;
  res.json({
    authenticated: true,
    admin: {
      id: session.admin_id,
      email: session.email,
      name: session.name,
      role: session.role
    }
  });
});
apiRouter.post("/admin/logout", (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7).trim() : req.headers["x-admin-token"];
  logoutAdmin(token);
  res.json({ success: true, message: "Logged out successfully." });
});
apiRouter.post("/admin/change-password", requireAdminAuth, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: "Current password and new password are required." });
    }
    const session = req.adminSession;
    changeAdminPassword(currentPassword, newPassword, session?.email);
    res.json({ success: true, message: "Password updated successfully." });
  } catch (err) {
    res.status(400).json({ error: err?.message || "Failed to update password." });
  }
});
apiRouter.get("/admin/stats", requireAdminAuth, (req, res) => {
  try {
    const stats = getAdminStatistics();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err?.message || "Failed to fetch statistics." });
  }
});
apiRouter.get("/admin/students", requireAdminAuth, (req, res) => {
  try {
    const { search, stream, status, state, district, block, sortBy, sortOrder, page, limit } = req.query;
    const result = getAdminStudentsList({
      search,
      stream,
      status,
      state,
      district,
      block,
      sortBy,
      sortOrder,
      page: page ? Number(page) : 1,
      limit: limit ? Number(limit) : 25
    });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err?.message || "Failed to fetch students list." });
  }
});
apiRouter.get("/admin/students/:registrationId", requireAdminAuth, (req, res) => {
  const student = getAllStudents().find(
    (s) => s.registration_id.trim().toUpperCase() === req.params.registrationId.trim().toUpperCase()
  );
  if (!student) {
    return res.status(404).json({ error: "Student not found." });
  }
  res.json(student);
});
apiRouter.patch("/admin/students/:registrationId/status", requireAdminAuth, async (req, res) => {
  try {
    let { status } = req.body;
    if (!["Pending", "Approval", "Admitted", "Rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status. Must be Pending, Approval, or Rejected." });
    }
    if (status === "Admitted") {
      status = "Approval";
    }
    const session = req.adminSession;
    const updated = await updateStudentAdmissionStatus(req.params.registrationId, status, session.email);
    res.json({
      success: true,
      message: status === "Approval" || status === "Admitted" ? "Student admission approved successfully." : status === "Rejected" ? "Student rejected successfully." : "Student status updated successfully.",
      student: updated
    });
  } catch (err) {
    res.status(400).json({ error: err?.message || "Failed to update admission status." });
  }
});
apiRouter.put("/admin/students/:registrationId", requireAdminAuth, async (req, res) => {
  try {
    const session = req.adminSession;
    const updated = await updateStudentDetails(req.params.registrationId, req.body, session.email);
    res.json({
      success: true,
      message: "Student details updated successfully.",
      student: updated
    });
  } catch (err) {
    res.status(400).json({ error: err?.message || "Failed to update student details." });
  }
});
apiRouter.delete("/admin/students/:registrationId", requireAdminAuth, async (req, res) => {
  try {
    const session = req.adminSession;
    await deleteStudent(req.params.registrationId, session.email);
    res.json({
      success: true,
      message: "Student registration deleted successfully."
    });
  } catch (err) {
    res.status(400).json({ error: err?.message || "Failed to delete student registration." });
  }
});
apiRouter.post("/admin/students/bulk-status", requireAdminAuth, async (req, res) => {
  try {
    let { registration_ids, status } = req.body;
    if (!Array.isArray(registration_ids) || registration_ids.length === 0) {
      return res.status(400).json({ error: "registration_ids array is required." });
    }
    if (!["Pending", "Approval", "Admitted", "Rejected"].includes(status)) {
      return res.status(400).json({ error: "Invalid status. Must be Pending, Approval, or Rejected." });
    }
    if (status === "Admitted") {
      status = "Approval";
    }
    const session = req.adminSession;
    const result = await bulkUpdateAdmissionStatus(registration_ids, status, session.email);
    res.json({
      success: true,
      message: `Successfully updated ${result.updatedCount} students to ${status}.`,
      ...result
    });
  } catch (err) {
    res.status(400).json({ error: err?.message || "Bulk status update failed." });
  }
});
apiRouter.post("/admin/students/bulk-delete", requireAdminAuth, async (req, res) => {
  try {
    const { registration_ids } = req.body;
    if (!Array.isArray(registration_ids) || registration_ids.length === 0) {
      return res.status(400).json({ error: "registration_ids array is required." });
    }
    const session = req.adminSession;
    const result = await bulkDeleteStudents(registration_ids, session.email);
    res.json({
      success: true,
      message: `Successfully deleted ${result.deletedCount} students.`,
      ...result
    });
  } catch (err) {
    res.status(400).json({ error: err?.message || "Bulk delete failed." });
  }
});
apiRouter.get("/admin/export", requireAdminAuth, (req, res) => {
  try {
    const { status, stream, state, district, block, format } = req.query;
    let students = getAllStudents();
    if (status && status !== "All") {
      students = students.filter((s) => s.admission_status.toLowerCase() === status.toLowerCase());
    }
    if (stream && stream !== "All") {
      students = students.filter((s) => s.stream.toLowerCase() === stream.toLowerCase());
    }
    if (state && state !== "All") {
      students = students.filter((s) => s.state.toLowerCase() === state.toLowerCase());
    }
    if (district && district !== "All") {
      students = students.filter((s) => s.district.toLowerCase() === district.toLowerCase());
    }
    if (block && block !== "All") {
      students = students.filter((s) => s.block.toLowerCase() === block.toLowerCase());
    }
    if (format === "json") {
      return res.json(students);
    }
    const headers = [
      "Registration ID",
      "Student Name",
      "Gmail",
      "Age",
      "Stream",
      "Subject 1",
      "Subject 2",
      "Subject 3",
      "Subject 4",
      "Subject 5",
      "Subject 6",
      "State",
      "District",
      "Block",
      "Address",
      "Admission Status",
      "Registration Date",
      "Admission Date"
    ];
    const csvRows = [headers.join(",")];
    for (const s of students) {
      const row = [
        `"${s.registration_id}"`,
        `"${s.full_name.replace(/"/g, '""')}"`,
        `"${s.gmail}"`,
        s.age,
        `"${s.stream}"`,
        `"${s.subject_1.replace(/"/g, '""')}"`,
        `"${s.subject_2.replace(/"/g, '""')}"`,
        `"${s.subject_3.replace(/"/g, '""')}"`,
        `"${s.subject_4.replace(/"/g, '""')}"`,
        `"${s.subject_5.replace(/"/g, '""')}"`,
        `"${s.subject_6.replace(/"/g, '""')}"`,
        `"${s.state.replace(/"/g, '""')}"`,
        `"${s.district.replace(/"/g, '""')}"`,
        `"${s.block.replace(/"/g, '""')}"`,
        `"${s.address.replace(/"/g, '""')}"`,
        `"${s.admission_status}"`,
        `"${s.registration_date}"`,
        `"${s.admission_date || ""}"`
      ];
      csvRows.push(row.join(","));
    }
    const csvContent = csvRows.join("\r\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="MY_CHSE_Students_${Date.now()}.csv"`);
    return res.send(csvContent);
  } catch (err) {
    res.status(500).json({ error: err?.message || "Export failed." });
  }
});
apiRouter.get("/admin/audit-logs", requireAdminAuth, (req, res) => {
  try {
    const logs = getAuditLogs(50);
    res.json(logs);
  } catch (err) {
    res.status(500).json({ error: err?.message || "Failed to fetch audit logs." });
  }
});

// server.ts
async function startServer() {
  const app = (0, import_express2.default)();
  const PORT = 3e3;
  app.use(import_express2.default.json());
  app.use("/api", apiRouter);
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path3.default.join(process.cwd(), "dist");
    app.use(import_express2.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path3.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`MY CHSE 12TH CLASSES server running on http://0.0.0.0:${PORT}`);
    syncFromSupabaseToLocal().then((synced) => {
      if (synced > 0) {
        console.log(`Initial boot: synced ${synced} existing students from Supabase to local cache.`);
      }
    }).catch((e) => console.warn("Supabase initial sync error:", e));
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
